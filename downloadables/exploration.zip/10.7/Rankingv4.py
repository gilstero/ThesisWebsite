# Below is a implementation of a NP ranking algorithm for non-binary treatments
# this is the same as v3 but with some negative marginals

# The code below is written by Olin Gilster

import pulp
import matplotlib.pyplot as plt
import numpy as np
# pulp is a linear programming library in Python: https://pypi.org/project/PuLP/
# the specific solver used here is a linear programming solver that includes precedence constraints


# Generate 20 patients, each with 4 treatment levels (baseline 0)
np.random.seed(42)
n = 100
L = 4
levels = []

for i in range(n):
    # Generate raw random increments (some positive, some negative)
    increments = np.random.normal(loc=1, scale=1, size=L)
    
    # Optional tweak: make about 25% of patients have at least one negative marginal
    if np.random.rand() < 0.25:
        neg_idx = np.random.choice(L, size=np.random.randint(1, L), replace=False)
        increments[neg_idx] *= -1  # flip some increments to negative
    
    # Compute cumulative levels (starting at 0 baseline)
    base = np.insert(np.cumsum(increments), 0, 0)
    
    levels.append(base.tolist())


n = len(levels)
L = len(levels[0]) - 1

print()
print("====DEBUG OUTPUT====")
print(f"Number of patients: {n}, number of treatment levels: {L}")

# print the max budget
maxBudget = n * L # max budget if everyone gets level L
print(f"Max budget (if everyone gets level {L}): {maxBudget}")
print()

def multipleChoiceKnapSackLP(levels, budget):

    n = len(levels)
    L = len(levels[0]) - 1

    # Compute marginal benefits
    marginals = [[levels[i][ell] - levels[i][ell-1] for ell in range(1, L+1)] for i in range(n)]
    print("====RUN WITH BUDGET:", budget, "====")
    for i in range(len(marginals)):
        print(f"Marginals for patient {i+1}: {marginals[i]}")

    # Initialize the model
    prob = pulp.LpProblem("MCKP", pulp.LpMaximize)
    x = [[pulp.LpVariable(f"x_{i}_{ell}", cat="Binary") for ell in range(1, L+1)] for i in range(n)]
    for i in range(len(x)):
        print(f"Decision variables for patient {i+1}: {[var.name for var in x[i]]}")

    print()

    # Objective function
    prob += pulp.lpSum(marginals[i][ell-1] * x[i][ell-1]
                       for i in range(n) for ell in range(1, L+1))
    print("Objective set to maximize sum of marginal benefits.")

    # Budget constraint
    prob += pulp.lpSum(x[i][ell-1] for i in range(n) for ell in range(1, L+1)) <= budget
    print(f"Added budget constraint: total increments ≤ {budget}")

    # Precedence constraints
    for i in range(n):
        for ell in range(2, L+1):
            prob += x[i][ell-1] <= x[i][ell-2]
            print(f"Added precedence: x_{i}_{ell} ≤ x_{i}_{ell-1}")

    print()

    # Solve the problem
    print("Solving...")
    prob.solve(pulp.PULP_CBC_CMD(msg=0))
    print("Solver status:", pulp.LpStatus[prob.status])

    # Extract solution
    increments = [[int(pulp.value(x[i][ell-1])) for ell in range(1, L+1)] for i in range(n)]
    value = pulp.value(prob.objective)

    debugReturn = []
    print("Objective value:", value)
    for i, incs in enumerate(increments):
        print(f"Patient {i+1} increments chosen: {incs} → total level {sum(incs)}")
        debugReturn.append(f"Patient {i+1} increments chosen: {incs} → total level {sum(incs)}")


    return value, increments, debugReturn

x1, y1, val1 = multipleChoiceKnapSackLP(levels, 2)
x2, y2, val2 = multipleChoiceKnapSackLP(levels, 3)
x3, y3, val3 = multipleChoiceKnapSackLP(levels, 4)

print("\n\n\n\n")
print("====MOVEMENT FROM ONE PATIENT TO ANOTHER AS BUDGET INCREASES====")
for i in range(len(val1)):
    print(val1[i])
print("----")
for i in range(len(val2)):
    print(val2[i])
print("----")
for i in range(len(val3)):   
    print(val3[i])  
print("====END CODE BLOCK====")

"""
Now beginning the full solver and backtracking results to show the full ranking as the budget increases
"""
valueList = []
incrementList = []
for b in range(1, maxBudget+1):
    val, inc, debug = multipleChoiceKnapSackLP(levels, b)
    valueList.append(val)
    incrementList.append(inc)

print()
# Compute TOC values
tocVals = [valueList[b-1]/b for b in range(1, maxBudget+1)]
print(f"tocVals: {tocVals}")
AUTOC = sum(tocVals) / len(tocVals)

print("\n=== AUTOC Results ===")
for b, toc in enumerate(tocVals, start=1):
    print(f"Budget {b}: TOC={toc:.3f}, Total benefit={valueList[b-1]:.2f}")
print(f"\nFinal AUTOC = {AUTOC:.3f}")

# Plot the TOC curve
u = [b for b in range(1, maxBudget+1)]
plt.figure(figsize=(6,4))
plt.plot(u, tocVals, marker="o")
plt.xlabel("Budget")
plt.ylabel("TOC(u) = V(b)/b")
plt.title(f"TOC curve via LP solver (AUTOC={AUTOC:.3f})")
plt.grid(True)
plt.show()

# === Generate aggregated heatmap ===
print("====Generating Aggregated Heatmap====")

# Compute total number of treatments per patient at each budget
aggregate_matrix = []
for b in range(1, maxBudget + 1):
    _, inc, _ = multipleChoiceKnapSackLP(levels, b)
    row = [sum(inc[i]) for i in range(n)]  # one value per patient (0–4)
    aggregate_matrix.append(row)

aggregate_matrix = np.array(aggregate_matrix)

# Plot as heatmap (1 col per patient, 1 row per budget)
fig, ax = plt.subplots(figsize=(14, 8))
im = ax.imshow(aggregate_matrix, cmap="Blues", aspect="auto", origin="upper")

# Label only x-axis (patients)
ax.set_xticks(np.arange(n))
ax.set_xticklabels([f"P{i+1}" for i in range(n)], rotation=90)
ax.set_xlabel("Patient")
ax.set_ylabel("Budget")

# Remove cluttered y-axis labels
ax.set_yticks([])

# Add title and colorbar
ax.set_title("Allocation Heatmap (Darker Blue = More Treatments per Patient)")
cbar = plt.colorbar(im, ax=ax)
cbar.set_label("Number of Treatments per Patient (0–4)")

plt.tight_layout()
plt.show()
