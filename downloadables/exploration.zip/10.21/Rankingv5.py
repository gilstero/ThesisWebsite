import pulp
import matplotlib.pyplot as plt
import numpy as np
# pulp is a linear programming library in Python: https://pypi.org/project/PuLP/
# the specific solver used here is a linear programming solver that includes precedence constraints

np.random.seed(42)
n = 10
L = 4
levels = []

for i in range(n):
    base = np.cumsum(np.abs(np.random.normal(1, 0.5, L)))  # positive increments
    base = np.insert(base, 0, 0)  # prepend 0 baseline
    levels.append(base.tolist())


n = len(levels)
L = len(levels[0]) - 1
maxBudget = n * L # max budget if everyone gets level L

def solve_mckp(levels, budget, lower_bounds=None):
    """
    levels: list of patients -> cumulative utilities [0, u1, u2, ..., uL]
    budget: number of increments allowed
    lower_bounds: same shape as x (n x L) with 0/1 lower bounds to enforce monotone carry-over
                  If None, no cross-budget monotonicity is enforced.
    """
    n = len(levels)
    L = len(levels[0]) - 1
    marginals = [[levels[i][ell] - levels[i][ell-1] for ell in range(1, L+1)] for i in range(n)]

    prob = pulp.LpProblem("MCKP", pulp.LpMaximize)
    x = [[pulp.LpVariable(f"x_{i}_{ell}", cat="Binary") for ell in range(1, L+1)] for i in range(n)]

    # Objective
    prob += pulp.lpSum(marginals[i][ell-1] * x[i][ell-1]
                       for i in range(n) for ell in range(1, L+1))

    # Budget
    prob += pulp.lpSum(x[i][ell-1] for i in range(n) for ell in range(1, L+1)) <= budget

    # Intra-patient precedence (ALWAYS ON)
    for i in range(n):
        for ell in range(2, L+1):
            prob += x[i][ell-1] <= x[i][ell-2]

    # Cross-budget monotonicity (only for "no-flip" series)
    if lower_bounds is not None:
        for i in range(n):
            for ell in range(1, L+1):
                if lower_bounds[i][ell-1] == 1:
                    prob += x[i][ell-1] >= 1

    prob.solve(pulp.PULP_CBC_CMD(msg=0))
    increments = [[int(pulp.value(x[i][ell-1])) for ell in range(1, L+1)] for i in range(n)]
    value = pulp.value(prob.objective)
    return value, increments


# === Build both series ===
value_noflip, value_flip = [], []
inc_noflip, inc_flip = [], []

lb = [[0]*L for _ in range(n)]

for b in range(1, maxBudget+1):
    # No-flip: solve with carry-forward lower bounds
    v_nf, inc_nf = solve_mckp(levels, b, lower_bounds=lb)
    value_noflip.append(v_nf)
    inc_noflip.append(inc_nf)
    # update lower bounds
    lb = [row[:] for row in inc_nf]

    # Flip-allowed: independent solve (still respects intra-patient precedence)
    v_f, inc_f = solve_mckp(levels, b, lower_bounds=None)
    value_flip.append(v_f)
    inc_flip.append(inc_f)

# TOC and AUTOC
u = np.arange(1, maxBudget+1)
toc_noflip = [value_noflip[b-1]/b for b in u]
toc_flip   = [value_flip[b-1]/b   for b in u]
AUTOC_noflip = float(np.mean(toc_noflip))
AUTOC_flip   = float(np.mean(toc_flip))

# Flip markers: budgets where any increment decreased vs the previous budget in the flip series
flip_points = []
for k in range(1, len(inc_flip)):
    prev = [sum(p) for p in inc_flip[k-1]]
    curr = [sum(p) for p in inc_flip[k]]
    if any(curr[i] < prev[i] for i in range(len(curr))):
        flip_points.append(k+1)  # budget index (1-based)

plt.figure(figsize=(7,5))
plt.plot(u, toc_noflip, label=f"Precedence-Enforced (AUTOC={AUTOC_noflip:.3f})", linewidth=2)
plt.plot(u, toc_flip,   label=f"Flipping Allowed (AUTOC={AUTOC_flip:.3f})", linewidth=2)

# Plot the TOC curves normally
plt.title("TOC Curves: Precedence-Enforced vs Flipping Allowed")
plt.xlabel("Budget")
plt.ylabel("TOC(u) = V(b)/b")
plt.grid(True, alpha=0.4)

# --- Put flip points along the x-axis ---
for fp in flip_points:
    plt.scatter(fp, 0, color='red', marker='v', s=80, zorder=5)  # red downward triangles on x-axis
    plt.text(fp, -0.05, f'{fp}', ha='center', va='top', color='red', fontsize=8, rotation=45)

# Adjust y-limits so the x-axis markers show clearly
ymin, ymax = plt.ylim()
plt.ylim(ymin - 0.2, ymax)

plt.legend()
plt.tight_layout()
plt.show()