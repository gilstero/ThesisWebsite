# below is an implementation of a AUTOC tree for non-binary treatments
# this is the first implementation of the tree in a function form
# future implementations will create the tree as a object

import numpy as np
import pandas as pd
from Rankingv2 import multipleChoiceKnapSackLP # import the MCKP solver from Rankingv1.py

# levels for patient treatment
levels = [[0, 1, 2, 3, 4],
          [0, 2, 3, 4, 6],
          [0, 1, 3, 4, 5],
          [0, 0.25, 2, 5, 8]  # this is a new ranking
]

# features: age and blood pressure
features = np.array([
    [25, 120],  # Patient 1: age=25, BP=120
    [45, 140],  # Patient 2: age=45, BP=140
    [35, 130],  # Patient 3: age=35, BP=130
    [60, 150]   # Patient 4: age=60, BP=150
])
feature_names = ["Age", "BloodPressure"]

n = len(levels)
L = len(levels[0]) - 1
maxBudget = n * L

patients = []
for pid, (level_row, feat_row) in enumerate(zip(levels, features), start=1):
    for ell in range(1, len(level_row)):  # increments
        patients.append({
            "Patient": pid,
            "Increment": ell,
            "MarginalBenefit": level_row[ell] - level_row[ell-1],
            "Age": feat_row[0],
            "BloodPressure": feat_row[1]
        })

df_increments = pd.DataFrame(patients)
print(df_increments)

def MCKPTreeSolver(df, feature_names, depth=0, prefix="", min_increments=2):
    """
    Recursive AUTOC tree builder with ASCII-style printout (increments as rows).
    """
    n = len(df)
    L = df["Increment"].max()

    # --------------------------------------------------------------------------
    # BASE CASE: Stopping rule
    # --------------------------------------------------------------------------
    # If there are too few increments in this group, stop splitting.
    # Instead, print the contents of the node ("leaf").
    if n <= min_increments:
        print(f"{prefix}Leaf: {n} increment(s) (stopping)")
        # Print out the increments contained in this node
        for _, row in df.iterrows():
            print(f"{prefix}  Patient {row['Patient']} Increment {row['Increment']} → MB={row['MarginalBenefit']}")
        return None

    # --------------------------------------------------------------------------
    # FUNCTION TO COMPUTE AUTOC
    # --------------------------------------------------------------------------
    # Given a subset of increments, rebuild them into cumulative levels
    # (so the solver can run MCKP), then compute AUTOC by averaging TOC(b).
    def compute_autoc(subset_df):
        if subset_df.empty:
            return 0

        grouped_levels = []
        # Rebuild levels per patient
        for pid, sub in subset_df.groupby("Patient"):
            increments = sub.sort_values("Increment")["MarginalBenefit"].tolist()
            # Convert marginal benefits into cumulative outcomes
            cum_levels = [0]
            for m in increments:
                cum_levels.append(cum_levels[-1] + m)
            grouped_levels.append(cum_levels)

        # Compute TOC values at all budgets up to number of increments
        vals = []
        for b in range(1, len(subset_df)+1):  # budget counts increments, not patients
            val, _, _ = multipleChoiceKnapSackLP(grouped_levels, b)
            vals.append(val / b)

        # AUTOC = average of TOC values
        return np.mean(vals)

    # --------------------------------------------------------------------------
    # SPLIT SEARCH: Try all feature splits
    # --------------------------------------------------------------------------
    best_split = None
    best_score = -1

    # Loop over all features we allow splits on
    for f_name in feature_names:
        thresholds = sorted(set(df[f_name]))  # candidate cut-points
        for thresh in thresholds:
            # Partition increments into left/right groups
            left_df = df[df[f_name] <= thresh]
            right_df = df[df[f_name] > thresh]

            # Skip invalid splits (empty group on either side)
            if left_df.empty or right_df.empty:
                continue

            # Compute AUTOC for both subgroups
            left_autoc = compute_autoc(left_df)
            right_autoc = compute_autoc(right_df)

            # Weighted average AUTOC (weighted by group size)
            weighted = (len(left_df)*left_autoc + len(right_df)*right_autoc) / n

            # Keep best split found so far
            if weighted > best_score:
                best_score = weighted
                best_split = (f_name, thresh, left_df, right_df, left_autoc, right_autoc)

    # --------------------------------------------------------------------------
    # IF NO SPLIT IMPROVES THINGS: Leaf
    # --------------------------------------------------------------------------
    if not best_split:
        print(f"{prefix}Leaf: no valid split")
        return None

    # --------------------------------------------------------------------------
    # APPLY BEST SPLIT
    # --------------------------------------------------------------------------
    f_name, thresh, left_df, right_df, l_autoc, r_autoc = best_split

    # Print split decision and subgroup statistics
    print(f"{prefix}Split on {f_name} ≤ {thresh}")
    print(f"{prefix}├── Left group: {len(left_df)} increments, AUTOC={l_autoc:.3f}")
    MCKPTreeSolver(left_df, feature_names, depth+1, prefix + "│   ", min_increments)

    print(f"{prefix}└── Right group: {len(right_df)} increments, AUTOC={r_autoc:.3f}")
    MCKPTreeSolver(right_df, feature_names, depth+1, prefix + "    ", min_increments)


print("\n==== Running AUTOC Tree Solver ====\n")
MCKPTreeSolver(df_increments, feature_names, depth=4, min_increments=2)


