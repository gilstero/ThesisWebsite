# AUTOC Tree Solver that splits on increments (not just patients)

import numpy as np
import pandas as pd
from Rankingv2 import multipleChoiceKnapSackLP  # import your solver

# --------------------------------------------------------------------------
# Example dataset
# --------------------------------------------------------------------------
levels = [[0, 1, 2, 3, 4],
          [0, 2, 3, 4, 6],
          [0, 1, 3, 4, 5],
          [0, 0.25, 2, 5, 8]]

features = np.array([
    [25, 120],  # Patient 1
    [45, 140],  # Patient 2
    [35, 130],  # Patient 3
    [60, 150]   # Patient 4
])
feature_names = ["Age", "BloodPressure"]

# --------------------------------------------------------------------------
# Expand into increments
# --------------------------------------------------------------------------
patients = []
for pid, (level_row, feat_row) in enumerate(zip(levels, features), start=1):
    for ell in range(1, len(level_row)):  # each increment
        patients.append({
            "Patient": pid,
            "Increment": ell,
            "MarginalBenefit": level_row[ell] - level_row[ell-1],
            "Age": feat_row[0],
            "BloodPressure": feat_row[1]
        })

df_increments = pd.DataFrame(patients)
print("\n=== Increments Data ===")
print(df_increments)


# --------------------------------------------------------------------------
# Tree Solver
# --------------------------------------------------------------------------
def MCKPTreeSolver(df, feature_names, depth=0, prefix="", min_increments=2):
    """
    Recursive AUTOC tree builder with ASCII-style printout (increments as rows).
    Each row in df is one (Patient, Increment).
    """
    n = len(df)

    # ----------------------------------------------------------------------
    # BASE CASE
    # ----------------------------------------------------------------------
    if n <= min_increments:
        print(f"{prefix}Leaf: {n} increment(s) (stopping)")
        for _, row in df.iterrows():
            print(f"{prefix}  Patient {row['Patient']} Increment {row['Increment']} → MB={row['MarginalBenefit']}")
        return None

    # ----------------------------------------------------------------------
    # AUTOC calculation: use the increments in this subset only
    # ----------------------------------------------------------------------
    def compute_autoc(subset_df):
        if subset_df.empty:
            return 0

        # reconstruct per-patient cumulative levels but only from increments present in this subset
        grouped_levels = []
        for pid, sub in subset_df.groupby("Patient"):
            increments = sub.sort_values("Increment")["MarginalBenefit"].tolist()
            cum_levels = [0]
            for m in increments:
                cum_levels.append(cum_levels[-1] + m)
            grouped_levels.append(cum_levels)

        vals = []
        for b in range(1, len(subset_df) + 1):  # budget is # of increments
            val, _, _ = multipleChoiceKnapSackLP(grouped_levels, b)
            vals.append(val / b)
        return np.mean(vals)

    # ----------------------------------------------------------------------
    # SPLIT SEARCH
    # ----------------------------------------------------------------------
    best_split = None
    best_score = -1

    for f_name in feature_names:
        thresholds = sorted(set(df[f_name]))
        for thresh in thresholds:
            left_df = df[df[f_name] <= thresh]
            right_df = df[df[f_name] > thresh]

            if left_df.empty or right_df.empty:
                continue

            left_autoc = compute_autoc(left_df)
            right_autoc = compute_autoc(right_df)
            weighted = (len(left_df) * left_autoc + len(right_df) * right_autoc) / n

            if weighted > best_score:
                best_score = weighted
                best_split = (f_name, thresh, left_df, right_df, left_autoc, right_autoc)

    # ----------------------------------------------------------------------
    # IF NO SPLIT
    # ----------------------------------------------------------------------
    if not best_split:
        print(f"{prefix}Leaf: no valid split")
        return None

    # ----------------------------------------------------------------------
    # APPLY BEST SPLIT
    # ----------------------------------------------------------------------
    f_name, thresh, left_df, right_df, l_autoc, r_autoc = best_split
    print(f"{prefix}Split on {f_name} ≤ {thresh}")
    print(f"{prefix}├── Left group: {len(left_df)} increments, AUTOC={l_autoc:.3f}")
    MCKPTreeSolver(left_df, feature_names, depth + 1, prefix + "│   ", min_increments)

    print(f"{prefix}└── Right group: {len(right_df)} increments, AUTOC={r_autoc:.3f}")
    MCKPTreeSolver(right_df, feature_names, depth + 1, prefix + "    ", min_increments)


print("\n==== Running AUTOC Tree Solver ====\n")
MCKPTreeSolver(df_increments, feature_names, depth=5, min_increments=2)