# just the MCKP code with no debug prints
import pulp

def multipleChoiceKnapSackLP(levels, budget):

    n = len(levels)
    L = len(levels[0]) - 1

    # Compute marginal benefits
    marginals = [[levels[i][ell] - levels[i][ell-1] for ell in range(1, L+1)] for i in range(n)]
   

    # Initialize the model
    prob = pulp.LpProblem("MCKP", pulp.LpMaximize)
    x = [[pulp.LpVariable(f"x_{i}_{ell}", cat="Binary") for ell in range(1, L+1)] for i in range(n)]


    # Objective function
    prob += pulp.lpSum(marginals[i][ell-1] * x[i][ell-1]
                       for i in range(n) for ell in range(1, L+1))

    # Budget constraint
    prob += pulp.lpSum(x[i][ell-1] for i in range(n) for ell in range(1, L+1)) <= budget

    # Precedence constraints
    for i in range(n):
        for ell in range(2, L+1):
            prob += x[i][ell-1] <= x[i][ell-2]
            


    # Solve the problem
    prob.solve(pulp.PULP_CBC_CMD(msg=0))
    # Extract solution
    increments = [[int(pulp.value(x[i][ell-1])) for ell in range(1, L+1)] for i in range(n)]
    value = pulp.value(prob.objective)

    debugReturn = []
    for i, incs in enumerate(increments):
        debugReturn.append(f"Patient {i+1} increments chosen: {incs} → total level {sum(incs)}")


    return value, increments, debugReturn