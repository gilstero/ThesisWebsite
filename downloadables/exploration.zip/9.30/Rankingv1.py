# Below is a implementation of a NP ranking algorithm for non-binary treatments

# The code below is written by Olin Gilster

import pulp
import matplotlib.pyplot as plt
import numpy as np
# pulp is a linear programming library in Python: https://pypi.org/project/PuLP/
# the specific solver used here is a linear programming solver that includes precedence constraints

# Below deotes 4 patients and their respective treatment effects
# I have included a case where the treatment effects are better for patient 4 as opposed to patient 2 but only after 1 level
levels = [[0, 1, 2, 3, 4],
          [0, 2, 3, 4, 6],
          [0, 1, 3, 4, 5],
          [0, 0.25, 2, 5, 8]  # this is a new ranking
]

n = len(levels)
L = len(levels[0]) - 1

print()
print("====DEBUG OUTPUT====")
print(f"Number of patients: {n}, number of treatment levels: {L}")

# print the max budget
maxBudget = n * L # max budget if everyone gets level L
print(f"Max budget (if everyone gets level {L}): {maxBudget}")
print()

def multipleChoiceKnapSackLP(levels, budget):

    n = len(levels)
    L = len(levels[0]) - 1

    # Compute marginal benefits
    marginals = [[levels[i][ell] - levels[i][ell-1] for ell in range(1, L+1)] for i in range(n)]
    print("====RUN WITH BUDGET:", budget, "====")
    for i in range(len(marginals)):
        print(f"Marginals for patient {i+1}: {marginals[i]}")

    # Initialize the model
    prob = pulp.LpProblem("MCKP", pulp.LpMaximize)
    x = [[pulp.LpVariable(f"x_{i}_{ell}", cat="Binary") for ell in range(1, L+1)] for i in range(n)]
    for i in range(len(x)):
        print(f"Decision variables for patient {i+1}: {[var.name for var in x[i]]}")

    print()

    # Objective function
    prob += pulp.lpSum(marginals[i][ell-1] * x[i][ell-1]
                       for i in range(n) for ell in range(1, L+1))
    print("Objective set to maximize sum of marginal benefits.")

    # Budget constraint
    prob += pulp.lpSum(x[i][ell-1] for i in range(n) for ell in range(1, L+1)) <= budget
    print(f"Added budget constraint: total increments ≤ {budget}")

    # Precedence constraints
    for i in range(n):
        for ell in range(2, L+1):
            prob += x[i][ell-1] <= x[i][ell-2]
            print(f"Added precedence: x_{i}_{ell} ≤ x_{i}_{ell-1}")

    print()

    # Solve the problem
    print("Solving...")
    prob.solve(pulp.PULP_CBC_CMD(msg=0))
    print("Solver status:", pulp.LpStatus[prob.status])

    # Extract solution
    increments = [[int(pulp.value(x[i][ell-1])) for ell in range(1, L+1)] for i in range(n)]
    value = pulp.value(prob.objective)

    debugReturn = []
    print("Objective value:", value)
    for i, incs in enumerate(increments):
        print(f"Patient {i+1} increments chosen: {incs} → total level {sum(incs)}")
        debugReturn.append(f"Patient {i+1} increments chosen: {incs} → total level {sum(incs)}")


    return value, increments, debugReturn

x1, y1, val1 = multipleChoiceKnapSackLP(levels, 2)
x2, y2, val2 = multipleChoiceKnapSackLP(levels, 3)
x3, y3, val3 = multipleChoiceKnapSackLP(levels, 4)

print("\n\n\n\n")
print("====MOVEMENT FROM ONE PATIENT TO ANOTHER AS BUDGET INCREASES====")
for i in range(len(val1)):
    print(val1[i])
print("----")
for i in range(len(val2)):
    print(val2[i])
print("----")
for i in range(len(val3)):   
    print(val3[i])  
print("====END CODE BLOCK====")

"""
Now beginning the full solver and backtracking results to show the full ranking as the budget increases
"""
valueList = []
incrementList = []
for b in range(1, maxBudget+1):
    val, inc, debug = multipleChoiceKnapSackLP(levels, b)
    valueList.append(val)
    incrementList.append(inc)

print()
# Compute TOC values
tocVals = [valueList[b-1]/b for b in range(1, maxBudget+1)]
print(f"tocVals: {tocVals}")
AUTOC = sum(tocVals) / len(tocVals)

print("\n=== AUTOC Results ===")
for b, toc in enumerate(tocVals, start=1):
    print(f"Budget {b}: TOC={toc:.3f}, Total benefit={valueList[b-1]:.2f}")
print(f"\nFinal AUTOC = {AUTOC:.3f}")

# Plot the TOC curve
u = [b for b in range(1, maxBudget+1)]
plt.figure(figsize=(6,4))
plt.plot(u, tocVals, marker="o")
plt.xlabel("Budget")
plt.ylabel("TOC(u) = V(b)/b")
plt.title(f"TOC curve via LP solver (AUTOC={AUTOC:.3f})")
plt.grid(True)
plt.show()

print("====Ranking Output====")
matrix = []
for b in range(1, maxBudget+1):
    _, inc, _ = multipleChoiceKnapSackLP(levels, b)
    row = []
    for i in range(n):
        row.extend(inc[i])   # flatten patient i's increments into the row
    matrix.append(row)

# Print matrix with headers
print("\n=== Ranking Matrix (1 = increment chosen at budget b) ===")
header = "Budget".ljust(8) + "".join([f"P{p+1}-L{ell}".rjust(6) for p in range(n) for ell in range(1, L+1)])
print(header)
for b, row in enumerate(matrix, start=1):
    row_str = f"{b}".ljust(8) + "".join([f"{val:>6d}" for val in row])
    print(row_str)

# below is the print-out of this in mat-plot lib
matrix = np.array(matrix)

fig, ax = plt.subplots(figsize=(10,8))
im = ax.imshow(matrix, cmap="Greys", aspect="auto")

# Add grid lines
ax.set_xticks(np.arange(-0.5, matrix.shape[1], 1), minor=True)
ax.set_yticks(np.arange(-0.5, matrix.shape[0], 1), minor=True)
ax.grid(which="minor", color="black", linestyle='-', linewidth=0.5)
ax.tick_params(which="minor", bottom=False, left=False)

# Label axes
ax.set_xticks(np.arange(matrix.shape[1]))
ax.set_xticklabels([f"P{p+1}-L{ell}" for p in range(n) for ell in range(1, L+1)], rotation=90)
ax.set_yticks(np.arange(matrix.shape[0]))
ax.set_yticklabels(np.arange(1, maxBudget+1))

ax.set_xlabel("Patient-Increment")
ax.set_ylabel("Budget")
ax.set_title("Ranking Matrix (grid view)")

plt.tight_layout()
plt.show()